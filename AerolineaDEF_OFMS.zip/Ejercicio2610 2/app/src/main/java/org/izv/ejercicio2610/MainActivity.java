package org.izv.ejercicio2610;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.material.snackbar.Snackbar;

import java.util.Locale;
import java.util.Random;

@SuppressLint("UseSwitchCompatOrMaterialCode")
public class MainActivity extends AppCompatActivity {

    // Declaring the variables;
    Switch swPrimera,swVentanilla,swMascota;
    CheckBox cbDiversidad, cbDesayuno, cbAlmuerzo, cbCena, cbSeguro, cbTerms;
    ImageButton ibPremium;
    ImageView imageView2;
    EditText etFecha, etOrigen, etDestino, etNombre, etApellidos, etTelefono;
    String extras, sumueue;
    // Moving from MainActivity to ActivityCost;
    Button btCont1; //btCont2;
    protected static final int REQUESTCODE_SECOND_ACTIVITY = 10;
    // Initializing every string variable that's gonna be contained inside extras.
    // Since switchs and checkboxes default value is false and I set String's values after OnClicks, these will work as "!x.isChecked()" values.
    String primeraclase = "viaje en turista ";
    String ventana = "asiento en pasillo ";
    String mascota = "sin mascota ";
    String diversidad = "asiento sin acondicionamiento ";
    String desayuno = "sin desayuno ";
    String almuerzo = "sin almuerzo ";
    String cena = "sin cena ";
    String seguro = "sin seguro de viajes";

    int sumatotal = 0;
    int costerandom = 0;
    int maximo = 1000;
    public static final String EXTRA_NUMBER = "totalcost.forthetrip";
    public static final String EXTRA_EXTRA = "lkasujdashgdas";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // To establish Toolbar as our ActionBar;
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        etNombre = findViewById(R.id.etNombre);
        etApellidos = findViewById(R.id.etApellidos);
        etTelefono = findViewById(R.id.etTelefono);
        etFecha = findViewById(R.id.etFecha);
        etOrigen = findViewById(R.id.etOrigen);
        etDestino = findViewById(R.id.etDestino);

        // Referencing the switches from activity_main.xml;
        swPrimera = (Switch) findViewById(R.id.swPrimera);
        swVentanilla = (Switch) findViewById(R.id.swVentanilla);
        swMascota = (Switch) findViewById(R.id.swMascota);

        // Referencing every checkbox from activity_main.xml;
        cbDiversidad = (CheckBox) findViewById(R.id.cbDiversidad);
        cbDesayuno = (CheckBox) findViewById(R.id.cbDesayuno);
        cbAlmuerzo = (CheckBox) findViewById(R.id.cbAlmuerzo);
        cbCena = (CheckBox) findViewById(R.id.cbCena);
        cbSeguro = (CheckBox) findViewById(R.id.cbSeguro);
        cbTerms = (CheckBox) findViewById(R.id.cbTerms);

        // Referencing the imagebutton variable to its element on activity_main.xml;
        ibPremium = (ImageButton) findViewById(R.id.ibPremium);

        // Referencing extra elements for the extra exercise;
        imageView2 = (ImageView) findViewById(R.id.imageView2);

        // setSupportActionBar(toolbar); Me da error. No puedo mostrar el menú en la Toolbar, y a falta de los apuntes se hace más difícil;

        /*
         * Every OnClickListener needed in the activity are listed in the same order as above;
         */

        // Setting OnClickListener on every (switch) variable so a Toast pops-up;
        swPrimera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Ha cambiado la configuración de 'Primera clase'", Toast.LENGTH_SHORT).show();
                // If after clicked the switched remains checked/true:
                if (swPrimera.isChecked()){ // First class seat;
                    primeraclase = "viajará en primera clase ";
                }
            }
        });

        swVentanilla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // If after clicked the switched remains checked/true:
                if (swVentanilla.isChecked()){ // Window seat;
                    ventana = "asiento con ventanilla ";
                }
                // Extra toast 2 (error);
                showErrorToast();
            }
        });

        swMascota.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // If after clicked the switched remains checked/true:
                if (swMascota.isChecked()){ // Pet onboard;
                    mascota = "requiere espacio para mascota ";
                }
                // Extra toast 3 (info);
                showInfoToast();
            }
        });

        // Setting OnClickListener on every (checkbox) variable so a Snackbar pops-up;
        cbDiversidad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // If after clicked the checkbox remains checked/true:
                if (cbDiversidad.isChecked()){
                    diversidad = "requiere asiento acondicionado a diversidad/es funcional/es ";
                }

                // As requested on the activity, I must set this one as an error message, showing the user the option to retry;
                Snackbar.make(v, "Ha ocurrido un fallo al cambiar la configuración de 'Diversidad Funcional'", Snackbar.LENGTH_LONG)
                        .setActionTextColor(getResources().getColor(R.color.azul))
                        .setAction("REINTENTAR", new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Log.i("Snackbar", "Ha pulsado REINTENTAR");
                            }
                        }).show();
            }
        });

        cbDesayuno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // If after clicked the checkbox remains checked/true:
                if (cbDesayuno.isChecked()){
                    desayuno = "quiere desayuno ";
                }
                Snackbar.make(v, "Ha cambiado la configuración de 'Desayuno'", Snackbar.LENGTH_LONG).show();
            }
        });

        cbAlmuerzo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // If after clicked the checkbox remains checked/true:
                if (cbAlmuerzo.isChecked()){
                    almuerzo = "quiere almuerzo ";
                }
                Snackbar.make(v, "Ha cambiado la configuración de 'Almuerzo'", Snackbar.LENGTH_LONG).show();
            }
        });

        cbCena.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // If after clicked the checkbox remains checked/true:
                if (cbCena.isChecked()){
                    cena = "quiere cena ";
                }
                Snackbar.make(v, "Ha cambiado la configuración de 'Cena'", Snackbar.LENGTH_LONG).show();
            }
        });

        cbSeguro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // If after clicked the checkbox remains checked/true:
                if (cbSeguro.isChecked()){
                    seguro = "ha contratado el seguro de viaje";
                }
                Snackbar.make(v, "Ha cambiado la configuración de 'Seguro de viaje'", Snackbar.LENGTH_LONG).show();
            }
        });

        cbTerms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Snackbar.make(v, "Ha cambiado la configuración de 'Términos y condiciones'", Snackbar.LENGTH_LONG).show();
            }
        });

        // Setting OnClickListener on the (imagebutton) variable so an AlertDialog pops-up;
        ibPremium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // Instancing a new AlertDialog and customizing it with what was requested in the activity;
                AlertDialog.Builder dialog1 = new AlertDialog.Builder(MainActivity.this);
                dialog1.setTitle("Importante");
                dialog1.setMessage("¿Acepta las condiciones del servicio premium?");
                dialog1.setCancelable(false);

                dialog1.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    // I set a new OnClick so it registers the action on this option
                    public void onClick(DialogInterface dialog1, int id) {
                        aceptar();
                    }
                });
                dialog1.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    // I set a new OnClick so it registers the action on this option
                    public void onClick(DialogInterface dialog1, int id) {
                        cancelar();
                    }
                });
                dialog1.show();
            }
        });

        // OnClick for ImageView2;
        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCheckToast();
            }
        });
        
        // OnClick to reach ActivityCost;
        btCont1 = findViewById(R.id.btCont1);
        btCont1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveFrom1to2();
            }
        });
    }

    public void moveFrom1to2() {
        // For randomizing the cost;
        String origen_s = etOrigen.getText().toString();
        String destino_s = etDestino.getText().toString();
        String date_s = etFecha.getText().toString();
        String total = date_s + destino_s + origen_s;
        String totalNoCase = total.toLowerCase(Locale.ROOT);

        for (int i = 0; i < totalNoCase.length() ;i++) {
            int as = totalNoCase.charAt(i);
            sumatotal = sumatotal + as;
        }

        Random r = new Random();

        r.setSeed(sumatotal);
        costerandom = r.nextInt(maximo);
        sumueue = String.valueOf(costerandom);

        Bundle bundle = new Bundle();

        bundle.putString("nombre", etNombre.getText().toString());
        bundle.putString("apellidos", etApellidos.getText().toString());
        bundle.putString("telefono", etTelefono.getText().toString());
        bundle.putString("origen", etOrigen.getText().toString());
        bundle.putString("destino", etDestino.getText().toString());
        bundle.putString("precio", sumueue);

        extras = primeraclase + ", " + ventana + ", " + mascota + ", " + diversidad + ", " + desayuno + ", " + almuerzo + ", " + cena + "y " + seguro + "." ;
        bundle.putString("extras", extras);

        Intent intentTo9 = new Intent(this, ActivityCost.class);
        intentTo9.putExtras(bundle);
        startActivity(intentTo9);
        
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }
    // functionality for menu
    @SuppressLint("NonConstantResourceId")
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_cuenta:
                Toast.makeText(this,
                        "Has pulsado la opción Mi cuenta", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_datos:
                Toast.makeText(this,
                        "Has pulsado la opción Datos Personales", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_docviajes:
                Toast.makeText(this,
                        "Has pulsado la opción Mis documentos de viaje", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_doccompa:
                Toast.makeText(this,
                        "Has pulsado la opción Mis compañeros de viaje", Toast.LENGTH_SHORT).show();
                String url5 = "https://www.ryanair.com/es/es/trip/manage";
                Intent i5 = new Intent(Intent.ACTION_VIEW);
                i5.setData(Uri.parse(url5));
                startActivity(i5);
                return true;
            case R.id.action_viajes:
                Toast.makeText(this,
                        "Has pulsado la opción Mis viajes", Toast.LENGTH_SHORT).show();

                return true;
            case R.id.action_embar:
                Toast.makeText(this,
                        "Has pulsado la opción Tarjetas de embarque", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_info:
                Toast.makeText(this,
                        "Has pulsado la opción Información sobre el vuelo", Toast.LENGTH_SHORT).show();
                String url4 = "https://help.ryanair.com/hc/es-es/articles/360017825038-Asientos-adicionales";
                Intent i4 = new Intent(Intent.ACTION_VIEW);
                i4.setData(Uri.parse(url4));
                startActivity(i4);
                return true;
            case R.id.action_infoact:
                Toast.makeText(this,
                        "Has pulsado la opción Info actualizada", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_regalo: // Clicking this option will show us a certain prize;
                Toast.makeText(this,
                        "Has pulsado la opción Vales de regalo", Toast.LENGTH_SHORT).show();
                String url = "https://imgur.com/a/s07hOVL";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
                return true;
            case R.id.action_revista:
                Toast.makeText(this,
                        "Has pulsado la opción Revista de vuelo", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_termcond: // Clicking on this menu will show us a page;
                String url2 = "https://help.ryanair.com/hc/es-es/articles/360017824658-Pol%C3%ADtica-de-equipaje-Ryanair";
                Intent i2 = new Intent(Intent.ACTION_VIEW);
                i2.setData(Uri.parse(url2));
                startActivity(i2);
                return true;
            case R.id.action_ayuda:
                Toast.makeText(this,
                        "Has pulsado la opción Centro de ayuda", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_contact:
                Toast.makeText(this,
                        "Has pulsado la opción Contactar con la aerolínea", Toast.LENGTH_SHORT).show();
                String url3 = "https://help.ryanair.com/hc/es-es/articles/360017684097-Espa%C3%B1a";
                Intent i3 = new Intent(Intent.ACTION_VIEW);
                i3.setData(Uri.parse(url3));
                startActivity(i3);
                return true;
            case R.id.action_politic:
                Toast.makeText(this,
                        "Has pulsado la opción Política de privacidad", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.action_config:
                Toast.makeText(this,
                        "Has pulsado la opción Configuración de privacidad", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    // Methods show_Toast are to reference, instance and show the custom toasts;
    private void showCheckToast() {
        // I'll custom the toast for the 'Success' message and insert it here;
        LayoutInflater inflater1 = getLayoutInflater();
        View layout = inflater1.inflate(R.layout.toastcheck_layout, (ViewGroup) findViewById(R.id.toastcheck));

        Toast toastsuccess = new Toast(getApplicationContext());
        toastsuccess.setGravity(Gravity.CENTER, 0,0);
        toastsuccess.setDuration(Toast.LENGTH_SHORT);
        toastsuccess.setView(layout);
        toastsuccess.show();
    }

    private void showErrorToast() {
        LayoutInflater inflater2 = getLayoutInflater();
        View layout = inflater2.inflate(R.layout.toasterror_layout, (ViewGroup) findViewById(R.id.toasterror));

        Toast toasterror = new Toast(getApplicationContext());
        toasterror.setGravity(Gravity.CENTER, 0,0);
        toasterror.setDuration(Toast.LENGTH_SHORT);
        toasterror.setView(layout);
        toasterror.show();
    }

    private void showInfoToast() {
        LayoutInflater inflater3 = getLayoutInflater();
        View layout = inflater3.inflate(R.layout.toastinfo_layout, (ViewGroup) findViewById(R.id.toastinfo));

        Toast toastinfo = new Toast(getApplicationContext());
        toastinfo.setGravity(Gravity.CENTER, 0,0);
        toastinfo.setDuration(Toast.LENGTH_SHORT);
        toastinfo.setView(layout);
        toastinfo.show();
    }

    // If the user clicks on "Aceptar" it shows a toast welcoming him/her to the PREMIUM membership;
    private void aceptar() {
        Toast.makeText(MainActivity.this,"Bienvenido a la experiencia PREMIUM", Toast.LENGTH_SHORT).show();
    }

    // When the users selects "Cancelar" we suggest him to reconsider joining the PREMIUM experience;
    private void cancelar() {
        Toast.makeText(MainActivity.this,"Reconsidere las ventajas que conlleva ser PREMIUM", Toast.LENGTH_SHORT).show();
    }
}