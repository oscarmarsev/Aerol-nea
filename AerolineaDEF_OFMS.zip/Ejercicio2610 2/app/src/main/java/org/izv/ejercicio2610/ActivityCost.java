package org.izv.ejercicio2610;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ActivityCost extends AppCompatActivity {

    protected static final int REQUESTCODE_FIRST_ACTIVITY = 10;
    Button btContinuar, btAtras;
    TextView tvCoste, tvNombre2, tvApellidos2, tvNumerotelf2,tvTrip2,tvExtras2;
    // public static final String EXTRA_NUMBER = "totalcost.forthetrip";
    String nombre, apellidos, telefono, trip, extras, precio, origen, destino;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cost);

        tvCoste = findViewById(R.id.tvCoste);
        tvNombre2 = findViewById(R.id.tvNombre2);
        tvApellidos2 = findViewById(R.id.tvApellidos2);
        tvNumerotelf2 = findViewById(R.id.tvNumerotelf2);
        tvTrip2 = findViewById(R.id.tvTrip2);
        tvExtras2 = findViewById(R.id.tvExtras2);

        btContinuar = findViewById(R.id.btContinuar);
        btAtras = findViewById(R.id.btAtras);

        // We capture the bundle created on the MainActivity. Also, we extract the data declaring our variables and setting the bundle values on them;
        Intent intent9 = getIntent(); // We recieve the bundle;
        Bundle bundle = intent9.getExtras(); // We harvest the values;

        nombre = bundle.getString("nombre");
        apellidos = bundle.getString("apellidos");
        telefono = bundle.getString("telefono");
        origen = bundle.getString("origen");
        destino = bundle.getString("destino");
        trip = origen + "-" + destino;
        extras = bundle.getString("extras");
        precio = bundle.getString("precio");

        tvNombre2.setText(nombre);
        tvApellidos2.setText(apellidos);
        tvNumerotelf2.setText(telefono);
        tvTrip2.setText(trip);
        tvExtras2.setText(extras);
        tvCoste.setText("" + precio);

        btContinuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveFrom2to3();
            }
        });

        btAtras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveFrom2to1();
            }
        });


    }

    private void moveFrom2to1() {
        Intent intent3 = new Intent(this, MainActivity.class);
        startActivityForResult(intent3, REQUESTCODE_FIRST_ACTIVITY);
    }

    private void moveFrom2to3() {
        Bundle bundle3From2 = new Bundle();

        bundle3From2.putString("nombre2", tvNombre2.getText().toString());
        bundle3From2.putString("apellidos2", tvApellidos2.getText().toString());
        bundle3From2.putString("telefono2", tvNumerotelf2.getText().toString());
        bundle3From2.putString("trip2", tvTrip2.getText().toString());
        bundle3From2.putString("extras2", tvExtras2.getText().toString());
        bundle3From2.putString("precio2", tvCoste.getText().toString());

        Intent intent2To3 = new Intent(this, ActivityAbstract.class);
        intent2To3.putExtras(bundle3From2);
        startActivity(intent2To3);

    }
}