package org.izv.ejercicio2610;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ActivityAbstract extends AppCompatActivity {

    Button btFinalizar;
    TextView tvNombreR, tvApellidosR, tvOrigenR, tvNumerotelfR, tvExtrasR, tvPrecioR;
    String nombre3, apellidos3, telefono3, trip3, extras3, precio3, extrasA, extrasB;
    protected static final int REQUESTCODE_FIRST_ACTIVITY = 10;


    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abstract);
        tvNombreR = findViewById(R.id.tvNombreR);
        tvApellidosR = findViewById(R.id.tvApellidosR);
        tvOrigenR = findViewById(R.id.tvOrigenR);
        tvNumerotelfR = findViewById(R.id.tvNumerotelfR);
        tvExtrasR = findViewById(R.id.tvExtrasR);
        tvPrecioR = findViewById(R.id.tvPrecioR);

        Intent intent2To3 = getIntent();
        Bundle bundle = intent2To3.getExtras();

        nombre3 = bundle.getString("nombre2");
        apellidos3 = bundle.getString("apellidos2");
        telefono3 = bundle.getString("telefono2");
        trip3 = bundle.getString("trip2");
        extras3 = bundle.getString("extras2");
        precio3 = bundle.getString("precio2");

        tvNombreR.setText(nombre3);
        tvApellidosR.setText(apellidos3);
        tvNumerotelfR.setText(telefono3);
        tvOrigenR.setText(trip3);
        tvExtrasR.setText("Ha contratado " + extras3);
        tvPrecioR.setText("" + precio3);



        // Go from Abstract to Main;
        btFinalizar = findViewById(R.id.btFinalizar);
        btFinalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveFrom3to1();
            }
        });

    }

    private void moveFrom3to1() {
        Intent intent4 = new Intent(this, MainActivity.class);
        startActivityForResult(intent4, REQUESTCODE_FIRST_ACTIVITY);
    }
}